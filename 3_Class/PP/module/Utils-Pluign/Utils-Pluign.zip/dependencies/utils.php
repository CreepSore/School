<?php
    class GGN_Utils {
        public static function GetNextId(string $tableName, string $idColumnName) {
            $db = JFactory::getDbo();
            $query = $db->getQuery(true);
    
            $query->select($db->quoteName($idColumnName))->from($db->quoteName($tableName))->order($idColumnName);
            $db->setQuery($query);
            $result = $db->loadObjectList();

            if(!$result) {
                echo "[GetNextId] Query failed! QUERY: $query";
                return false;
            }

            return ($result[0][$idColumnName] + 1);
        }
		
		
		public static function GetUserInformationByUserId(string $userId) {
            $db = JFactory::getDbo();
			$query = $db->getQuery(true);

			$query
				->select(array('*'))
				->from($db->quoteName('ggn_users', 'users'))
				->where($db->quoteName('UserId') . ' = '. $db->quote($userId));

			$db->setQuery($query);
			$result= $db->loadObjectList();
			return $result;
        }
		
		
		public static function GetUserInformationFromEmail(string $email) {
            $db = JFactory::getDbo();
			$query = $db->getQuery(true);

			$query
				->select(array('*'))
				->from($db->quoteName('ggn_users', 'users'))
				->where($db->quoteName('Email') . ' = '. $db->quote($email));

			$db->setQuery($query);
			$result= $db->loadObjectList();
			return $result;
        }
		
		public static function VerifyActionCode($userId, $code) {
            $db = JFactory::getDbo();
			$query = $db->getQuery(true);

			$query
				->select(array('*'))
				->from($db->quoteName('ggn_actioncode', 'action'))
				->where(array($db->quoteName('ActionParameter') . ' = '. $db->quote($userId),$db->quoteName('Code') . ' = '. $db->quote($code)));

			$db->setQuery($query);
			$result= $db->loadObjectList();
						
			return sizeof($result) > 0;
        }
		
		public static function DeactivateEventByParticipantId($participantId, $eventId) {
            $db = JFactory::getDbo();
			$query = $db->getQuery(true);

			$fields = array( $db->quoteName('Active') . ' = 0' );

			// Conditions for which records should be updated.
			$conditions = array(
				$db->quoteName('ParticipantId') . ' = ' . $db->quote($participantId),
				$db->quoteName('EventId') . ' = '.$db->quote($eventId)
			);

			$query->update($db->quoteName('ggn_participant'))->set($fields)->where($conditions);


			$db->setQuery($query);
			$result= $db->loadObjectList();
						
			return sizeof($result) > 0;
        }
		
		public static function VerifyPhoneNumber($userId, $phone) {
            $db = JFactory::getDbo();
			$query = $db->getQuery(true);

			$query
				->select(array('*'))
				->from($db->quoteName('ggn_users', 'users'))
				->where(array($db->quoteName('UserId') . ' = '. $db->quote($userId),$db->quoteName('TelephoneNumber') . ' LIKE '. $db->quote('%'.$phone)));

			$db->setQuery($query);
			$result= $db->loadObjectList();
						
			return sizeof($result) > 0;
        }
		
		
		public static function GetEventsByUserId(string $userId) {
            $db = JFactory::getDbo();
            $query = $db->getQuery(true);
    				
			$query
				->select(array('title', 'dateStart', 'dateEnd', 'concat_ws(\' \',ggn_participant.FirstName,ggn_participant.LastName) as Name', 'TIMESTAMPDIFF(YEAR, Birthdate, CURDATE()) as Age','EventId','ParticipantId'))
				->from($db->quoteName('ggn_users', 'users'))
				->join('INNER', $db->quoteName('ggn_participant') . ' using(' . $db->quoteName('UserId') . ')')
				->join('INNER', $db->quoteName('ggn_event') . ' using(' . $db->quoteName('EventId') . ')')
				->where($db->quoteName('UserId') . ' = '. $db->quote($userId));
				
            $db->setQuery($query);
			$result = $db->loadObjectList();

            return $result;
        }
		
		public static function GetEventByParticipant(string $eventId, string $participantId) {
            $db = JFactory::getDbo();
            $query = $db->getQuery(true);
    				
			$query
				->select(array('title', 'dateStart', 'dateEnd', 'concat_ws(\' \',ggn_participant.FirstName,ggn_participant.LastName) as Name', 'TIMESTAMPDIFF(YEAR, Birthdate, CURDATE()) as Age','EventId','ParticipantId'))
				->from($db->quoteName('ggn_users', 'users'))
				->join('INNER', $db->quoteName('ggn_participant') . ' using(' . $db->quoteName('UserId') . ')')
				->join('INNER', $db->quoteName('ggn_event') . ' using(' . $db->quoteName('EventId') . ')')
				->where(array($db->quoteName('ParticipantId') . ' = '. $db->quote($participantId), $db->quoteName('EventId') . ' = '. $db->quote($eventId)));
				
            $db->setQuery($query);
			$result = $db->loadObjectList();

            return $result;
        }

        public static function RandomString(int $length, $useLowercase = false) {
            $usedChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            if($useLowercase) {
                $usedChars .= strtolower($usedChars);
            }
            $usedChars .= '1234567890';

            $chars = str_split($usedChars);
            $result = "";
            for($i = 0; $i < $length; $i++) {
                $result = $result . $chars[array_rand($chars)];
            }
            return $result;
        }
		
		public static function ReadFileContent($path, bool $asArray = false) {
            $hFile = fopen($path, "r");
            if($asArray) {
                $data = [];
            } else {
                $data = "";
            }

            while($line = fgets($hFile)) {
                if($asArray) {
                    $data[] = $line;
                } else {
                    $data .= $line;
                }            
            }

            return $data;
        }
    }
?>