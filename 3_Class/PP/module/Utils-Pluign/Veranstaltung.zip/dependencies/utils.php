<?php
    class GGN_Utils {
        public static function GetNextId(string $tableName, string $idColumnName) {
            $db = JFactory::getDbo();
            $query = $db->getQuery(true);
    
            $query->select($db->quoteName($idColumnName))->from($db->quoteName($tableName))->order($idColumnName);
            $db->setQuery($query);
            $result = $db->loadObjectList();

            if(!$result) {
                echo "[GetNextId] Query failed! QUERY: $query";
                return false;
            }

            return ($result[0][$idColumnName] + 1);
        }
		
		
		public static function GetUserInformationByUserId(string $userId) {
            $db = JFactory::getDbo();
			$query = $db->getQuery(true);

			$query
				->select(array('*'))
				->from($db->quoteName('ggn_users', 'users'))
				->where($db->quoteName('UserId') . ' LIKE '. $db->quote($userId));

			$db->setQuery($query);
			$result= $db->loadObjectList();
			return $result;
        }
		
		
		public static function GetEventsByUserId(string $userId) {
            $db = JFactory::getDbo();
            $query = $db->getQuery(true);
    				
			$query
				->select(array('title', 'dateStart', 'dateEnd', 'concat_ws(\' \',ggn_participant.FirstName,ggn_participant.LastName)', 'TIMESTAMPDIFF(YEAR, Birthdate, CURDATE())','Birthdate'))
				->from($db->quoteName('ggn_users', 'users'))
				->join('INNER', $db->quoteName('ggn_participant', 'participant') . ' ON ' . $db->quoteName('users.UserId') . ' = ' . $db->quoteName('participant.UserId'))
				->join('INNER', $db->quoteName('ggn_event', 'event') . ' ON ' . $db->quoteName('participant.EventId') . ' = ' . $db->quoteName('event.EventId'));
				
            $db->setQuery($query);
			$result = $db->loadObjectList();

            return $result;
        }

        public static function RandomString(int $length, $useLowercase = false) {
            $usedChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            if($useLowercase) {
                $usedChars .= strtolower($usedChars);
            }
            $usedChars .= '1234567890';

            $chars = str_split($usedChars);
            $result = "";
            for($i = 0; $i < $length; $i++) {
                $result = $result . $chars[array_rand($chars)];
            }
            return $result;
        }
		
		public static function ReadFileContent($path, bool $asArray = false) {
            $hFile = fopen($path, "r");
            if($asArray) {
                $data = [];
            } else {
                $data = "";
            }

            while($line = fgets($hFile)) {
                if($asArray) {
                    $data[] = $line;
                } else {
                    $data .= $line;
                }            
            }

            return $data;
        }
    }
?>