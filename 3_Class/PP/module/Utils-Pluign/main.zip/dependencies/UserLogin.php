<?php
class UserLogin {
    public static function uuid(){
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    public static function SaveLoginData(string $Gender, string $FirstName,string $LastName,string $Email, int $TelephoneNumber,string $EventId) {


        $db = JFactory::getDbo();
        $query = $db->getQuery(true);


        $uuid = UserLogin::uuid();

        $columns = array(
            'UserID',
            'Gender',
            'FirstName',
            'LastName',
            'EMail',
            'TelephoneNumber'
        );

        $data = array(
            $uuid,
            $Gender,
            $FirstName,
            $LastName,
            $Email,
            $TelephoneNumber
        );


        $query->insert($db->quoteName('ggn_users'))->columns($db->quoteName($columns))->values(implode(',', $db->quote($data)));
        $db->setQuery($query);
        $db->execute();

        UserLogin::setParticipant($uuid, $FirstName, $LastName, $Active, $EventId);
		return uuid;
    }

    public static function getMaxParticipants($EventId){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('maxParticipants');
        $query->from($db->quoteName('ggn_event'));
        $query->where($db->quoteName('EventId') . ' = '. $db->quote($EventId));

        $db->setQuery($query);
        $maxNumber = $db->loadResult();

        return $maxNumber;

    }

    public static function getParticipantsNumber($EventId) {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query->select('COUNT(*)');
        $query->from($db->quoteName('ggn_participant'));
        $query->where($db->quoteName('EventId') . ' = '. $db->quote($EventId));

        $db->setQuery($query);
        $currentNumber = $db->loadResult();

        return $currentNumber;
    }

    public static function setParticipant(string $Uuid, string $FirstName, string $LastName,int Active, string $EventId){

        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $ParticipantId = UserLogin::uuid();

        $columns = array(
            'UserID',
            'ParticipantId',
            'FirstName',
            'LastName',
            'Active',
            'EventId',
            'BirthDate'
        );

        $data = array(
            $Uuid,
            $ParticipantId,
            $FirstName,
            $LastName,
            $Active,
            $EventId,
            null
        );

        $query->insert($db->quoteName('ggn_participant'))->columns($db->quoteName($columns))->values(implode(',', $db->quote($data)));
        $db->setQuery($query);
        $db->execute();

    }
		
	
    public static function addChild(string $Uuid, string $FirstName, string $LastName,int Active, string $EventId, string $BirthDate){

        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $ParticipantId = UserLogin::uuid();

        $columns = array(
            'UserID',
            'ParticipantId',
            'FirstName',
            'LastName',
            'Active',
            'EventId',
            'BirthDate'
        );

        $data = array(
            $Uuid,
            $ParticipantId,
            $FirstName,
            $LastName,
            $Active,
            $EventId,
            $BirthDate
        );

        $query->insert($db->quoteName('ggn_participant'))->columns($db->quoteName($columns))->values(implode(',', $db->quote($data)));
        $db->setQuery($query);
        $db->execute();

    }
	
	public static getWaitList(string $WaitlistId){
		GetNextId('WaitlistId', $WaitlistId);
	}
	
	public static setWaitList(string $ParticipantId, string EventId, string $WaitlistId, Datetime TimeStamp ){
		
		    $columns = array(
            'WaitlistId',
            'TimeStamp',
            'EventId',
            'ParticipantId',
        );

        $data = array(
            $WaitlistId,
            $TimeStamp, 
            $EventId,
			$ParticipantId
           
        );
		
		
		$query->insert($db->quoteName('ggn_waitlist'))->columns($db->quoteName($columns))->values(implode(',', $db->quote($data)));
        $db->setQuery($query);
        $db->execute();
	}

    public static function GetNextId(string $tableName, string $idColumnName) {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query->select($db->quoteName($idColumnName))->from($db->quoteName($tableName))->order($idColumnName);
        $db->setQuery($query);
        $result = $db->loadObjectList();

        if(!$result) {
            echo "[GetNextId] Query failed! QUERY: $query";
            return false;
        }

        return ($result[0][$idColumnName] + 1);
    }
    public static function Test(){
        return "blablabla";
    }
}
?>