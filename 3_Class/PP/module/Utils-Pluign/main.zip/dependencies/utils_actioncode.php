<?php
require_once('utils.php');

class GGN_UtilsActionCode {	
    public static function AddAction(string $codeType, string $actionParameter, string $action) {
        $code = self::GenerateActionCode($codeType);

        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        
        $columns = array(
            'Code',
            'CodeType',
            'Action',
            'ActionParameter'
        );

        $data = array(
            $code,
            $codeType,
            $action,
            $actionParameter
        );

        $query->insert($db->quoteName('ggn_actioncode'))->columns($db->quoteName($columns))->values(implode(',', $db->quote($data)));
        $db->setQuery($query);
        $db->execute();

        return $code;
    }

    public static function GenerateActionCode(string $codeType) {
        $db = JFactory::getDbo();
        $CodeCount = function($code, $db) {
            $query = $db->getQuery(true);

            $query->select('*')->from($db->quoteName('ggn_actioncode'))->where($db->quoteName('code'). ' = ' .$db->quote($code));
            $db->setQuery($query);
            $result = $db->loadObjectList();
            return count($result);
        };

        switch($codeType) {
            case 'URL': 
                $code = '';
                do {
                    $code = GGN_Utils::RandomString(32, true);
                } while($CodeCount($code, $db) > 0);
                return $code;
                break;

            case 'ONETIME':
                $code = '';
                do {
                    $code = GGN_Utils::RandomString(6, false);
                } while($CodeCount($code, $db) > 0);
                return $code;
                break;

            default:
                return false;
                break;
        }
    }
}